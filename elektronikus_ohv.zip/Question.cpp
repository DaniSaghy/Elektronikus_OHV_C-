#include "Question.h"
#include <iostream>
#include "SizeofArray.h"

Question::Question(){		//param�ter n�lk�li konstruktor
	text = "";		//�res a k�rd�s
	comment = "";		//�res a komment
	answersNum = 0;		//v�laszok sz�ma nulla		
	value = -1;		//�rt�ke -1
}

Question::Question(std::string txt, int ansNum){			//param�teres konstruktor, egy stringet �s egy intet v�r, ezek lesznek a k�rd�s c�me �s a v�laszok sz�ma
	if(ansNum<1 && ansNum>6){		//megvizsg�ljuk helyes-e a v�laszok sz�ma
		std::cout<<"invalid answersnum"<<std::endl;
		return;
	}
	answersNum=ansNum;
	text=txt;		//be�ll�tjuk a a k�rd�s sz�veg�t
	switch (ansNum)
	{
	case 6:			//a v�laszok default teszt �rt�ke
		answers[5] = "five"; 
	case 5:
		answers[4] = "four"; 
	case 4:
		answers[3] = "three"; 
	case 3:
		answers[2] = "two"; 
	case 2:
		answers[1] = "one"; 	
	case 1:
		answers[0] = "zero"; 
	default:
		std::cout<<"something gone wrong in switch case"<<std::endl;
		break;
	}
}

Question::Question(std::string txt, std::string ans[]):answersNum(sizeofarray(ans)){		//a k�rd�s �s  v�laszok be�ll�t�shoz konstruktor
	if(answersNum<1 && answersNum>6){		//megvizsg�ljuk megfele� e a v�laszok sz�ma
		std::cout<<"invalid answersnum"<<std::endl;
		return;
	}
	text=txt;		//be�ll�tjuk a k�rd�s sz�veg�t
	for(int i =0;i<answersNum;i++){
		answers[i] = ans[i];		//�tm�soljuk a v�laszokat
	}
}

Question::~Question(void){		//kinull�z mindent
	for(int i=0;i<answersNum;i++){
		answers[i] = ""; 
	}	
	value = -2;
	answersNum= 0;
	comment = "";
	text = "";
}

void Question::setText(std::string txt){		//be�ll�tja a k�rd�s "c�m�t" sz�val mag�t a k�rd�st az �tvett stringre
	text = txt;
}

void Question::setAnswers(std::string Answers){			//�j v�laszlehet�s�get adhatunk hozz�, de ez csak akkor lesz sikeres ha a v�laszok sz�ma m�g nem 6
	if(answersNum<6){
		answers[answersNum++] = Answers;
	}
	else
		std::cout<<"nem lehet tobb valaszt hozza adni"<<"	a valaszok szama:"<<answersNum<<std::endl;
}

std::string Question::getComment(){			//visszaadja az adott k�rd�s kommentj�t
	return comment;
}

std::string Question::getText(){		//visszaadja az adott k�rd�s sz�veg�t
	return text;
}

int Question::getValue(){		//vissza adja az adott k�rd�s �rt�k�t
	return value;
}

bool Question::evaluation(std::string s){		//a k�rd��v �sszegz� f�ggv�ny�ben h�v�d�d ki�rt�kel� f�ggv�ny, mely  egy kapott stringr�l eld�nti hogy �rt�kes v�lasz (true) vagy comment-e (false)
	if(s.length() == 1){		//ha a kapott string hossza 1, akkor felt�telezhet�en helyes a v�lasz de k�zel sem biztos
		for(int i =0;i<answersNum;i++){			//egy ciklusban v�gig kell menni �s megvizsg�lni az adott k�rd�shez tartoz� v�laszokkal egyezik-e
			int first = answers[i].find_first_not_of("\t ");		 //mivel a v�laszok el�tt a stringben \t (tab) �ll, meg kell keresni az els� nem white space/�rt�kes karaktert �s kimentj�k ennek az index�t
			if(0 <= first){
				std::string tmp = answers[i].substr(first);		 //majd l�trehozunk egy ideiglenes stringet melybe �tm�soljuk a v�laszt az �rt�kes karaktert�l kezdve
				if(tmp[0] == s[0]){			//ha az ideiglenes string els� eleme megegyezik a kapott string�vel akkor a v�lasz �rt�kes �gy be is �ll�thatjuk az �rt�ke�t
					value = s[0]-'0';		//ez pedig az ascii t�vbl�nak k�sz�nhet�en k�nnynen megkaphat�
					return true;
				}
			}
		}
	}
	comment = s;		//ha nem helyes/�rt�kes v�laszt kaptunk elmentj�k a commentek k�z�
	return false;
}

void Question::changeQuestionNum(){			//szint�n az �sszegz� f�ggv�nyben h�v�dik
	int position = text.find('.');		 //megkeress�k az els� pontot a k�rd�s sz�veg�ben �s ennek kimetj�k a poz�ci�j�t
	if(0<=position){
		std::string tmp = text.substr(0,position);			//l�trehozunk egy ideiglenes stringet, melyben a k�rd�s sorsz�m�t t�roljuk, ez pedig a k�rd�s sz�vege az elej�t�l az els� pont karakterig
		int index = atoi(tmp.c_str());   //str to number
		index--;		//akkor haszn�ljuk ezt a f�ggv�nyt amikor elt�vol�tunk egy k�rd�st �gy cs�kkenetni kell a k�rd�sek sorsz�m�t 
		text = std::to_string(index)+text.substr(position);			//majd vissza�ll�tjuk a helyes k�rd�st, to_string int-b�l stringet konvert�l a substring hozz�f�z
	}
//	text[0] = (char)c;
}

void Question::removeAnswer(int n){			//elt�vol�tunk egy v�laszt, ennek a sorsz�m�t kell �tadni
	std::string tmp[6];			//l�trehozunk egy ideiglenes v�laszokat tartalmazo t�mb�t
	for(int i=0,j=0;i<6;i++){		//majd eg�szen od�ig m�soljuk �t a v�laszokaz am�g nem �r�nk el a t�r�lni k�v�nthoz, ezen a ponton ugrunk egyet majd a tov�bbikaat m�soljuk
		if(i==n-1){
			i++;
		}
		tmp[j++] = answers[i];
	}
	tmp[5] = "";		
	for(int i=0;i<6; i++){
	answers[i] = tmp[i];		//�t�l��tjuk a pointert
	}
	answersNum--;		
}

std::ostream& operator<<(std::ostream& os, const Question& question){		//operator<< overload, ez h�c�dik a k�rd��v kiir�t� oper�tor�n�l, az egyes k�rd�sekre
	os<<std::endl<<question.text;		//ki�rjuk a k�rd�s sz�veg�t
	for(int i =0;i<question.answersNum;i++){		//azt�n ciklusban a v�laszokat hozz�
		if(question.answers[i][0] != '\t'){
			os<<std::endl<<'\t'<<question.answers[i];
		}
		else
			os<<std::endl<<question.answers[i];
	}
	return os;
}