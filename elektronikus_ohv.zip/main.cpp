#include <iostream>
#include <fstream>
#include <string> 
#include "Questionnaire.h"
#include "Question.h"

Questionnaire& readQuestionnaire(std::string fileName,Questionnaire& q){		//f�jlb�l beolvas� f�ggv�ny, ami fel�p�t egy Questionnaie objektumot, param�terk�nt kap egy stringet(filename) �s egy Questionnaire referenci�t
	Question *question;
	bool isTitle = false;		//megvizsg�ljuk van-e m�r c�me a k�rd��vnek
	char line[500];
	std::string prewLine;
	std::string actLine;
	std::ifstream myFile(fileName,std::ios::in);		//megnyitjuk beolvas�sra
	if(myFile){
		while (!myFile.eof()) {			//addig olvasunk amig nem �r�nk a f�jl v�g�re
			myFile.getline(line,500);
			actLine=line;
			if('0'<=line[0]  && line[0]<='9'){		//ha a beolvasott string els� karaktere sz�m, tudni fogjuk hogy k�rd�st olvastunk
				if(!isTitle){
					q.setTitle(prewLine);		//amikor el�sz�r l�p�nk ide az azt jelenti hogy beolvastuk az els� k�rd�st, az el�z� sor pedig a c�m volt
					isTitle=true;
				}
				question = new Question();			//l�trehozunk egy �j Questiont
				question->setText(actLine);			//be�ll�tjuk a k�rd�s sz�veg�t
				q.addQuestion(question);		//hozz� adjuk a k�rd��vhez a k�rd�st		
			}
			else if(actLine.at(0) == '\t'){			//ha '\t'-t olvasunk akkor v�lasz k�vetkezik
				question->setAnswers(actLine);		
			}
//			std::cout<<line<<std::endl;
			prewLine = line;
		 }
	}
	return q;
}

void writeQuestionnarie(Questionnaire q,std::string fileName){			//f�jl-ba ki�ro f�ggv�ny egy Questionnaire-t �s egy stringet kap, a string a f�jl neve, a Questionnaire pedig a ki�rand� k�rd��v
	std::ofstream myfile(fileName,std::ios::out);		//megnyitjuk a f�jlt �jra�r�sra
	if(myfile.is_open() ){
		myfile<<q;
		myfile.close();                    
		std::cout <<"A file megirasa befejezodott!"; 
	}
	else {
		std::cout << "A file megnyitasa sikertelen volt.";			//ha nem siker�lt megnyitni
	}

}


Question createNewQuestion(){		//uj Question l�trehoz�sa
	bool a = false;
	Question q;
	std::string s;
	do{
			std::cout<<"Adja meg a kerdes szoveget, ugyeljen ra, hogy szammal kezdodjon!"<<std::endl;
			std::getline(std::cin,s);		//beolvassuk a user �ltal beadott sort
			if('0'<=s[0]  && s[0]<='9'){		//megvzsg�ljuk teljes�ti-e a felt�teleket
				q.setText(s);
				a = true;
			}
			else{
				std::cout<<"nem megfelelo a kerdes"<<std::endl;
			}
		}
	while(a != true);
	std::cout<<"Adja meg hany valaszt szeretne (max 6)!"<<std::endl;		
	std::getline(std::cin,s);
	int n = atoi(s.c_str());
	for(int i=0;i<n;i++){
		std::cout<<"adja meg a valaszt!"<<std::endl;		//felt�ltj�k a k�rd�sehez tartoz� v�laszokat
		std::getline(std::cin,s);
		s = std::to_string(i)+","+s;
		q.setAnswers(s);
	}
	return q;
}


using namespace std;

int main (){
	Questionnaire *questionnaires = new Questionnaire[1];
	int db=0;

	Questionnaire qe;
	readQuestionnaire("eloadas_kerdoiv.txt",qe);

	Questionnaire qg;
	readQuestionnaire("gyakorlat_kerdoiv.txt",qg);
	
	Questionnaire ql;
	readQuestionnaire("labor_kerdoiv.txt",ql);
	
	Questionnaire qta;
	readQuestionnaire("tantargy_kerdoiv.txt",qta);
	
	Questionnaire qte;
	readQuestionnaire("testnevles_kerdoiv.txt",qte);

	string s;
	Question qq;
	double x; 
    do {
		cout<<"0:	"<<"eloadas kerdoiv kitoltese"<<endl;
		cout<<"1:	"<<"gyakorlat kerdoiv kitoltese"<<endl;
		cout<<"2:	"<<"labor kerdoiv kitoltese"<<endl;
		cout<<"3:	"<<"tantargy kerdoiv kitoltese"<<endl;
		cout<<"4:	"<<"testnevles kerdoiv kitoltese"<<endl;
		cout<<"5:	"<<"uj kerdes letrehozasa"<<endl;
		cout<<"9:	"<<"kilepes"<<endl;
		cout<<"Adja meg a hasznalni kivant funkcio szamat"<<endl;
		getline(cin,s);
		if('0'<=s[0]  && s[0]<='9'){
				//atoi(s.c_str())
				switch (s[0]) {
					case '0': x = qe.summary();
							  qe.writeComments();
							  cout<<"A kerdoiv atlag pontszama:	"<<x<<endl<<endl;break;
					case '1': x=qg.summary();
							  qg.writeComments();
							  cout<<"A kerdoiv atlag pontszama:	"<<x<<endl<<endl;break;
					case '2': x=ql.summary();
							  ql.writeComments();
							  cout<<"A kerdoiv atlag pontszama:	"<<x<<endl<<endl;break;
					case '3': x=qta.summary();
							  qta.writeComments();
							  cout<<"A kerdoiv atlag pontszama:	"<<x<<endl<<endl;break;
					case '4': x=qte.summary();
							  qte.writeComments();
							  cout<<"A kerdoiv atlag pontszama:	"<<x<<endl<<endl;break;
					case '5': qq = createNewQuestion();
							  cout<<qq<<endl;break;
					default:  cout<<"A megadott lehetosegek kozul valasszon!"<<endl;
				}
		}
	}
	while (s[0] != '9');

return 0;
}