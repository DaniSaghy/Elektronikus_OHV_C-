#pragma once
#include <string>

extern int sizeofarray(std::string *array){			//extern f�ggv�ny, vissza adja h�ny elem� az �tadott string t�mb
    size_t i = 0;
    while (!array[i].empty())
        ++i;
//    std::cout << "Array length is: " << i << std::endl;
	return i;
};